import { NavLink, useLocation, Link } from 'react-router-dom';
import { SiteInfo } from '@/lib/constants';
import AppSettings from '@/components/AppSettings';
import { useAuthStore } from '@/stores/state';
import { cn } from '@/lib/utils';
import { useTranslation } from 'react-i18next';
import { navigationService } from '@/services/navigation';
import { ZapIcon, LogOutIcon } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/Tooltip';
import { useEffect, useState } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { firebaseLogout } from '@/api/firebaseAuth';

interface NavigationTab {
  label: string;
  value: string;
  path: string;
}

const staticTabs: NavigationTab[] = [
  { label: 'ChatIBC', value: 'askatul', path: '/retrieval' },
  { label: 'AssetsIBC', value: 'askip', path: '/map' },
  { label: 'Appeals', value: 'assets', path: '/appeals' },
  { label: 'Agents', value: 'forms', path: '/agents' },
  { label: 'Access', value: 'aboutus', path: '/access' },
];

const accessExtraTabs: NavigationTab[] = [
  { label: 'iDoc', value: 'idoc', path: '/access/idoc' },
  { label: 'iAsk', value: 'iask', path: '/access/iask' },
  { label: 'iGraph', value: 'igraph', path: '/access/igraph' },
  { label: 'iLog', value: 'ilog', path: '/access/ilog' },
];

const pathToLabelMap: Record<string, string> = {
  '/retrieval': 'ChatIBC',
  '/map': 'AssetsIBC', 
  '/appeals': 'Appeals',
  '/agents': 'Agents',
  '/access': 'Access',
  '/login': 'Login',
  '/graphs': 'Graphs',
  '/documents': 'Documents',
  '/wiki': 'Wiki',
  '/logs': 'Logs',
  '/profile': 'Profile',
  '/access/idoc': 'iDoc',
  '/access/iask': 'iAsk',
  '/access/igraph': 'iGraph',
  '/access/ilog': 'iLog'
};

function NavigationItem({ tab, isActive }: { tab: NavigationTab; isActive: boolean }) {
  return (
    <NavLink
      to={tab.path}
      className={cn(
        'cursor-pointer px-3 py-2 rounded-md text-sm font-medium transition-all',
        isActive
          ? 'bg-emerald-400 text-white'
          : 'text-muted-foreground hover:bg-accent'
      )}
    >
      {tab.label}
    </NavLink>
  );
}

function NavigationMenu({ guestMode }: { guestMode: boolean }) {
  const [tabs, setTabs] = useState<NavigationTab[]>([]);
  const location = useLocation();

  useEffect(() => {
    const availableTabs = staticTabs;
    
    const fetchTabs = async () => {
      try {
        const docRef = doc(db, 'admin_feature_tabs', 'access_config');
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const config = docSnap.data();
          // console.log('Firebase config loaded:', config);
          // console.log('Current guestMode:', guestMode);
          
          const filteredTabs = availableTabs.filter(tab => {
            let hasAccess = false;
            if (guestMode) {
              hasAccess = config[tab.value]?.public || false;
            } else {
              hasAccess = config[tab.value]?.public || 
                         config[tab.value]?.stakeholders || 
                         config[tab.value]?.team || 
                         config[tab.value]?.admin || false;
            }
            // console.log(`Tab ${tab.value}: hasAccess=${hasAccess}, customHeading="${config[tab.value]?.customHeading}", originalLabel="${tab.label}"`);
            return hasAccess;
          }).map(tab => {
            const customHeading = config[tab.value]?.customHeading;
            const customPath = config[tab.value]?.ipAddress || tab.path;
            
           
            let finalLabel = customHeading;
            if (!finalLabel && customPath !== tab.path) {
              finalLabel = pathToLabelMap[customPath] || tab.label;
            }
            if (!finalLabel) {
              finalLabel = tab.label;
            }
            
            // console.log(`Tab ${tab.value}: Final label will be "${finalLabel}" (custom: "${customHeading}", path: "${customPath}", original: "${tab.label}")`);
            // console.log(`Tab ${tab.value}: Final path will be "${customPath}" (original: "${tab.path}")`);
            return {
              ...tab,
              label: finalLabel,
              path: customPath,
            };
          });

          if (filteredTabs.length === 0) {
            // console.log('No tabs found after filtering, showing all tabs with custom headings');
            const fallbackTabs = availableTabs.map(tab => {
              const customHeading = config[tab.value]?.customHeading;
              const customPath = config[tab.value]?.ipAddress || tab.path;
              
              
              let finalLabel = customHeading;
              if (!finalLabel && customPath !== tab.path) {
                finalLabel = pathToLabelMap[customPath] || tab.label;
              }
              if (!finalLabel) {
                finalLabel = tab.label;
              }
              
              // console.log(`Fallback Tab ${tab.value}: Final label will be "${finalLabel}" (custom: "${customHeading}", path: "${customPath}", original: "${tab.label}")`);
              return {
                ...tab,
                label: finalLabel,
                path: customPath,
              };
            });
            setTabs(fallbackTabs);
          } else {
            // console.log('Final tabs to display:', filteredTabs);
            setTabs(filteredTabs);
          }
        } else {
          console.log('No Firebase config found, showing all tabs as fallback');
          setTabs(availableTabs); 
        }
              } catch (error) {
          console.error('Error fetching tabs:', error);
          console.log('Error occurred, showing all tabs as fallback');
          setTabs(availableTabs);
        }
    };

    fetchTabs();
  }, [guestMode]);

  return (
    <div className="flex items-center gap-2">
      {tabs.map(tab => (
        <NavigationItem
          key={tab.value}
          tab={tab}
          isActive={location.pathname.startsWith(tab.path)}
        />
      ))}
    </div>
  );
}

function AccessSubNavigation({ role }: { role?: string | null }) {
  const location = useLocation();
  const [tabs, setTabs] = useState<NavigationTab[]>([]);
  const isAccessPage = location.pathname.startsWith('/access');

  useEffect(() => {
    const fetchAccessTabs = async () => {
      try {
        const docRef = doc(db, 'admin_feature_tabs', 'access_config');
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const config = docSnap.data();
          console.log('Access tabs config loaded:', config);
          
          const updatedTabs = accessExtraTabs.map(tab => {
            let customHeading = config[tab.value]?.customHeading;
            const customPath = config[tab.value]?.ipAddress || tab.path;
            
            // Map admin settings to secondary header tabs
            if (tab.value === 'idoc') {
              // iDoc should use Documents custom heading
              customHeading = config['documents']?.customHeading || customHeading;
            } else if (tab.value === 'igraph') {
              // iGraph should use Graphs custom heading
              customHeading = config['graphs']?.customHeading || customHeading;
            } else if (tab.value === 'iask') {
              // iAsk should use AskAtul custom heading
              customHeading = config['askatul']?.customHeading || customHeading;
            } else if (tab.value === 'ilog') {
              // iLog should use Logs custom heading
              customHeading = config['logs']?.customHeading || customHeading;
            }
            
            
            let finalLabel = customHeading;
            if (!finalLabel && customPath !== tab.path) {
              finalLabel = pathToLabelMap[customPath] || tab.label;
            }
            if (!finalLabel) {
              finalLabel = tab.label;
            }
            
            console.log(`Access Tab ${tab.value}: Final label will be "${finalLabel}" (custom: "${customHeading}", path: "${customPath}", original: "${tab.label}")`);
            return {
              ...tab,
              label: finalLabel,
              path: customPath,
            };
          });
          setTabs(updatedTabs);
        } else {
          console.log('No Firebase config found for access tabs, using defaults');
          setTabs(accessExtraTabs);
        }
      } catch (error) {
        console.error('Error fetching access tabs config:', error);
        setTabs(accessExtraTabs);
      }
    };

    if (isAccessPage) {
      fetchAccessTabs();
    }
  }, [isAccessPage]);

  if (!isAccessPage) return null;

  return (
    <div className="flex justify-end items-center gap-2 px-4 py-2 border-b bg-background sticky top-[64px] z-40">
      {tabs.map(tab => (
        <NavigationItem
          key={tab.value}
          tab={tab}
          isActive={location.pathname === tab.path || location.pathname.startsWith(`${tab.path}/`)}
        />
      ))}
      {role === 'admin' && (
        <NavLink
          to="/access/admin-features"
          className={cn(
            'cursor-pointer px-3 py-2 rounded-md text-sm font-medium transition-all',
            location.pathname.startsWith('/access/admin-features')
              ? 'bg-emerald-400 text-white'
              : 'text-muted-foreground hover:bg-accent'
          )}
        >
          Admin
        </NavLink>
      )}
    </div>
  );
}

export default function SiteHeader({ guestMode = false }: { guestMode?: boolean }) {
  const { t } = useTranslation();
  const { role, plan, username, webuiTitle, webuiDescription } = useAuthStore();

  return (
    <>
      <header className="border-b border-border bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 flex h-16 w-full items-center justify-between px-4">
        {/* Left side - Logo + Branding */}
        <div className="flex items-center min-w-[200px]">
          <NavLink to={guestMode ? "/" : "/access"} className="flex items-center gap-2">
            <ZapIcon className="h-4 w-4 text-emerald-400" />
            <span className="font-bold">{SiteInfo.name}</span>
          </NavLink>
          {webuiTitle && (
            <div className="ml-2 flex items-center">
              <span className="mx-1 text-xs text-gray-500">|</span>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span className="text-sm font-medium cursor-default">
                      {webuiTitle}
                    </span>
                  </TooltipTrigger>
                  {webuiDescription && (
                    <TooltipContent>{webuiDescription}</TooltipContent>
                  )}
                </Tooltip>
              </TooltipProvider>
            </div>
          )}
        </div>

        {/* Center - Navigation Tabs */}
        <div className="flex flex-1 justify-center items-center">
          <NavigationMenu guestMode={guestMode} />
          {guestMode && (
            <span className="ml-2 px-2 py-1 text-xs bg-yellow-100 text-yellow-800 rounded-md">
              {t('login.guestMode', 'Guest Mode')}
            </span>
          )}
        </div>

        {/* Right - Actions */}
        <div className="w-[200px] flex justify-end items-center gap-2">
          <AppSettings />
          {plan ? (
            <button
              onClick={async () => {
                try {
                  await firebaseLogout();
                  useAuthStore.getState().logout();
                  navigationService.navigateToLogin();
                } catch (error) {
                  console.error('Logout failed:', error);
                }
              }}
              className="p-2 rounded-full hover:bg-muted transition-colors"
              aria-label="Logout"
            >
              <LogOutIcon className="h-4 w-4" />
            </button>
          ) : (
            <Link to="/login" className="text-sm hover:underline">Login</Link>
          )}
        </div>
      </header>

      <AccessSubNavigation role={role} />
    </>
  );
}
